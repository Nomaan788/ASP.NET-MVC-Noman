﻿using System.Web.Mvc;

namespace MySchool.MVC.Controllers
{
    public class AccountController : Controller
    {
        public ActionResult UserProfile()
        {
            return View();
        }

        public ActionResult ForgottenPassword()
        {
            return View();
        }

        public ActionResult ResetPassword()
        {
            return View();
        }

        public ActionResult ResetPasswordSuccess()
        {
            return View();
        }
    }
}