﻿using MySchool.MVC.Models;
using MySchool.MVC.ViewModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MySchool.MVC.Controllers
{
    public class RegisterController : Controller
    {
        private readonly MySchoolEntities dbContext;

        public RegisterController()
        {
            dbContext = new MySchoolEntities();
        }

        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(RegisterModel model)
        {
            var user = new User
            {
                FirstName = model.FirstName,
                LastName = model.LastName,
                Username = model.Username,
                Password = model.Password,
                Email = model.Email,
                MobileNo = model.MobileNo,
                IsActive = true,
                AddedDate = DateTime.Now
            };

            dbContext.Users.Add(user);
            var result = dbContext.SaveChanges();
            
            if (result > 0)
            {
                var file = model.ProfilePic;

                if (file != null && file.ContentLength > 0)
                {
                    var userId = user.Id;
                    string fileExtension = Path.GetExtension(file.FileName);

                    var uploadPath = "~/Files";
                    var fileName = $"Img_{userId}{fileExtension}";
                    var path = Path.Combine(Server.MapPath(uploadPath), fileName);
                    file.SaveAs(path);

                    user.ProfilePic = fileName;
                    dbContext.SaveChanges();
                }

                return RedirectToAction("Success");
            }                
            return View(model);
        }

        public ActionResult Success()
        {
            return View();
        }


        [HttpPost]
        public ActionResult UploadProfilePic(HttpPostedFileBase file)
        {
            if (file != null && file.ContentLength > 0)
            {
                // Validation
                string fileExtension = Path.GetExtension(file.FileName);
                string[] allowedExtensions = { ".pdf", ".doc", ".docx" };

                if (!allowedExtensions.Contains(fileExtension))
                {
                    ViewBag.Message = "Only pdf, doc and docx files are allowed.";
                    return View("Index");
                }

                var maxFileSize = 5 * 1024 * 1024; // 5MB
                if (file.ContentLength > maxFileSize)
                {
                    ViewBag.Message = "File size exceeds the maximum limit of 5MB.";
                    return View("Index");
                }

                // Save the file to the server or perform any other necessary operations
                var fileName = Path.GetFileName(file.FileName);
                var path = Path.Combine(Server.MapPath("~/Files"), fileName);
                file.SaveAs(path);

                ViewBag.Message = "File uploaded successfully";

            }
            else
            {
                ViewBag.Message = "Please select a file to upload.";
            }

            return View("Index");
        }
    }
}