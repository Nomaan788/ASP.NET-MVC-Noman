﻿using MySchool.MVC.Models;
using System.Linq;
using System.Web.Mvc;
using MySchool.MVC.ViewModels;

namespace MySchool.MVC.Controllers
{
    public class UserController : Controller
    {
        private readonly MySchoolEntities dbContext;

        public UserController()
        {
            dbContext = new MySchoolEntities();
        }

        // GET: User
        public ActionResult Users()
        {
            var result = dbContext
                .Users
                .Select(x => new UserModel
                {
                    Id = x.Id,
                    FirstName = x.FirstName,
                    LastName = x.LastName,
                    Username = x.Username,
                    Email = x.Email,
                    MobileNo = x.MobileNo,
                    Role = x.Role.Name,
                    SysAdmin = x.SysAdmin,
                    ProfilePic = "/Files/" + x.ProfilePic,
                    IsActive = x.IsActive,
                    AddedBy = x.User2.FirstName,
                    AddedDate = x.AddedDate,
                    ModifiedBy = x.User3.FirstName,
                    ModifiedDate = x.ModifiedDate
                }).OrderByDescending(x => x.Id)
                .ToList();

            //var result = (from u in dbContext.Users
            //              join r in dbContext.Roles on u.RoleId equals r.Id
            //              join ab in dbContext.Users on u.AddedById equals ab.Id
            //              join mb in dbContext.Users on u.AddedById equals mb.Id
            //              select new UserModel
            //              {
            //                  Id = u.Id,
            //                  FirstName = u.FirstName,
            //                  LastName = u.LastName,
            //                  Email = u.Email,
            //                  MobileNo = u.MobileNo,
            //                  Role = r.Name,
            //                  IsActive = u.IsActive,
            //                  AddedBy = ab.FirstName,
            //                  ProfilePic = "~/Files/" + u.ProfilePic,
            //                  //AddedBy = (ab.FirstName + ' ' + ab.LastName),
            //                  AddedDate = u.AddedDate,
            //                  ModifiedBy = mb.FirstName,
            //                  ModifiedDate = u.ModifiedDate
            //              }).ToList();

            return View(result);
        }
    }
}