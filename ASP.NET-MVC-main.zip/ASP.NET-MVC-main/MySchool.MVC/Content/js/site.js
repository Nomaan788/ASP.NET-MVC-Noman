
// This function allow only numbers
const numberOnly = (e) => {
    if (!(e.keyCode >= 48 && e.keyCode <= 57)) {
        e.preventDefault();
    }
}
